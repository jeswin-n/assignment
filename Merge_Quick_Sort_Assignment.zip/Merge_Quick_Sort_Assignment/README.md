# Merge Sort and Quick Sort Assignment

Sort the IDs: `324, 125, 456, 218, 102, 389, 275, 147`

## Files
- `merge_sort.c` — Merge Sort in C.
- `quick_sort.c` — Quick Sort in C using the last element as pivot.
- `input_data.txt` — input sequence.
- `output.txt` — expected output.
- `trace_tables.md` — intermediate merge passes and partition results.
- `complexity_analysis.md` — complexity and comparison.

## Compile and run with GCC
```bash
gcc merge_sort.c -o merge_sort
./merge_sort
gcc quick_sort.c -o quick_sort
./quick_sort
```
On Windows, run the generated `.exe` files after compiling.

Expected sorted output: `102 125 147 218 275 324 389 456`

## Upload to GitHub
1. Create a new repository on GitHub.
2. Extract this ZIP.
3. Upload the files and commit them.
4. Copy the repository URL and submit it.

This ZIP is the project package; it does not automatically create or host a GitHub repository.
