# Complexity Analysis

| Criterion | Merge Sort | Quick Sort |
|---|---|---|
| Main operation | Merge sorted subarrays | Partition around pivot |
| Passes/partitions for this input | 3 merge passes/levels | 5 partition calls with this pivot rule |
| Best time | O(n log n) | O(n log n) |
| Average time | O(n log n) | O(n log n) |
| Worst time | O(n log n) | O(n^2) |
| Additional space | O(n) | O(log n) average recursion stack; O(n) worst case |
| Stable | Yes | Generally no |

## Major operations
- Merge Sort divides the array and merges sorted sections. Worst-case time is O(n log n), with a temporary array.
- Quick Sort partitions around a pivot. It is often fast in practice, but poor pivot choices can cause O(n^2) time.

## Conclusion
Both programs sort the IDs into `102, 125, 147, 218, 275, 324, 389, 456`.
For predictable worst-case performance and stability, Merge Sort is suitable. Quick Sort often performs well in practice and uses less auxiliary array storage, but its worst case is O(n^2).

Note: The assignment says “after each digit position” for Merge Sort. Digit-position passes normally belong to Radix Sort. This project records Merge Sort after each merge pass.
