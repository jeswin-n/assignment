#include <stdio.h>
int partition(int a[], int l, int r) {
    int pivot = a[r], i = l - 1, temp;
    for (int j = l; j < r; j++) {
        if (a[j] <= pivot) {
            i++;
            temp = a[i]; a[i] = a[j]; a[j] = temp;
        }
    }
    temp = a[i + 1]; a[i + 1] = a[r]; a[r] = temp;
    return i + 1;
}
void quickSort(int a[], int l, int r) {
    if (l < r) {
        int p = partition(a, l, r);
        quickSort(a, l, p - 1);
        quickSort(a, p + 1, r);
    }
}
int main(void) {
    int a[] = {324, 125, 456, 218, 102, 389, 275, 147};
    int n = sizeof(a) / sizeof(a[0]), i;
    printf("Input: ");
    for (i = 0; i < n; i++) printf("%d ", a[i]);
    quickSort(a, 0, n - 1);
    printf("\nSorted output: ");
    for (i = 0; i < n; i++) printf("%d ", a[i]);
    printf("\n");
    return 0;
}
