# Trace Tables

Input: `324, 125, 456, 218, 102, 389, 275, 147`

## Merge Sort
Merge Sort records merge passes, not digit positions.

| Pass | Merges | Array after pass |
|---|---|---|
| 1 | (324,125), (456,218), (102,389), (275,147) | 125, 324, 218, 456, 102, 389, 147, 275 |
| 2 | (125,324)+(218,456); (102,389)+(147,275) | 125, 218, 324, 456, 102, 147, 275, 389 |
| 3 | Merge both sorted halves | 102, 125, 147, 218, 275, 324, 389, 456 |

## Quick Sort
Method: Lomuto partition; last element is pivot; comparison uses `<= pivot`.

| Partition | Subarray | Pivot | Array after partition |
|---|---|---:|---|
| 1 | Whole array | 147 | 125, 102, 147, 218, 324, 389, 275, 456 |
| 2 | 125, 102 | 102 | 102, 125, 147, 218, 324, 389, 275, 456 |
| 3 | 218, 324, 389, 275, 456 | 456 | 102, 125, 147, 218, 324, 389, 275, 456 |
| 4 | 218, 324, 389, 275 | 275 | 102, 125, 147, 218, 275, 389, 324, 456 |
| 5 | 389, 324 | 324 | 102, 125, 147, 218, 275, 324, 389, 456 |

Final sorted sequence: **102, 125, 147, 218, 275, 324, 389, 456**
